#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("input.dat");
ofstream fout("output.dat");

int M[100][100];
int n;     //noduri
int m;    //muchii

int main()
{
    fin >> n;
    fin >> m;

    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        M[x][y] = 1;
        M[y][x] = 1;
    }

    fout << n << endl;

    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++) fout << M[i][j] << " ";
        fout << endl;
    }

    return 0;
}
