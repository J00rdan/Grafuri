#include <iostream>
#include <fstream>
using namespace std;

int M[100][100];
int n;

ifstream fin("input.dat");
ofstream fout("output.dat");

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++) fin >> M[i][j];
    fout << n << endl << n + 1 << endl;
    for(int i = 1; i <= n; i++){
        int nr_noduri = 0;

        for(int j = 1; j <= n; j++){
            if(M[i][j] == 1) nr_noduri ++;
        }
        fout << nr_noduri << " ";

        for(int j = 1; j <= n; j++){
            if(M[i][j] == 1) fout << j << " ";
        }

        for(int j = nr_noduri + 1; j < n; j++) fout << "0 ";
        fout << endl;

    }
}
