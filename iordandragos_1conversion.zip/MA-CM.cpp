#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("input.dat");
ofstream fout("output.dat");

int M[100][100];
int n;


int main()
{
    fin >> n;
    fout << n << endl << n + 1 << endl;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++) fin >> M[i][j];

    for(int i = 1; i < n; i++){
        for(int j = i + 1; j <= n; j++){
            if(M[i][j] == 1) fout << i <<  " " << j << endl;
        }
    }

    return 0;
}
