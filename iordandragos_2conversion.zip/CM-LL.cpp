#include<fstream>
#include<iostream>
using namespace std;
int a[100][100];
int main()
{ int n,m;

    fstream f;
    f.open("input_f.dat",ios::in);
    fstream g;
    g.open("output_f.dat",ios::out);
    f>>n;
    f>>m;
     int x,y;
    for(int i=0;i<m;i++)
    {
        f>>x>>y;
        a[x-1][y-1]=1;
        a[y-1][x-1]=1;
    }
    int z=0;;
    for(int i=0;i<n;i++)
        {for(int j=0;j<n;j++)
        {
            if(a[i][j]==1)
                z++;
        }
        g<<z<<" ";
        for(int j=0;j<n;j++)
        {
            if(a[i][j]==1)
                g<<j+1<<" ";
        }
        for(int k=0;k<n-z-1;k++) g<<0<<" ";
        g<<endl;
        z=0;
        }


    f.close();
    g.close();
}
