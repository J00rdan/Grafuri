#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("input.dat");
ofstream fout("output.dat");

int n;
int M[100][100];

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++){
        int nr;
        fin >> nr;
        for(int j = 1; j < n; j++){
            int x;
            fin >> x;
            if(x != 0) M[i][x] = 1;
        }
    }
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++)
            fout << M[i][j] << " ";
        fout << endl;
    }
    return 0;
}
